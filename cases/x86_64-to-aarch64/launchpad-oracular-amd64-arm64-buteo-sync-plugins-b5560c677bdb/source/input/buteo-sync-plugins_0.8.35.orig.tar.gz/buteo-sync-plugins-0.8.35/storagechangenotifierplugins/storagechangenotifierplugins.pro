TEMPLATE = subdirs

SUBDIRS += hcontacts
