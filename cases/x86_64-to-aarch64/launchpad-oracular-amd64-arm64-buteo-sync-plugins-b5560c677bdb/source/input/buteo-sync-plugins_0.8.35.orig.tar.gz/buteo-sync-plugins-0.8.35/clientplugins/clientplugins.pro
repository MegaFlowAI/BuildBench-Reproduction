TEMPLATE = subdirs
SUBDIRS += syncmlclient
