TEMPLATE = subdirs
SUBDIRS += syncmlserver
