#ifndef lib1305_test_h
#define lib1305_test_h

#define aligned lib1305_test_aligned
#define callocplus lib1305_test_callocplus
#define checksum lib1305_test_checksum
#define checksum_clear lib1305_test_checksum_clear
#define checksum_expected lib1305_test_checksum_expected
#define double_canary lib1305_test_double_canary
#define endianness lib1305_test_endianness
#define forked lib1305_test_forked
#define input_compare lib1305_test_input_compare
#define input_prepare lib1305_test_input_prepare
#define myrandom lib1305_test_myrandom
#define ok lib1305_test_ok
#define output_compare lib1305_test_output_compare
#define output_prepare lib1305_test_output_prepare
#define public lib1305_test_public
#define secret lib1305_test_secret
#define targeti lib1305_test_targeti
#define targetn lib1305_test_targetn
#define targetoffset lib1305_test_targetoffset
#define targeto lib1305_test_targeto
#define targetp lib1305_test_targetp
#define valgrind lib1305_test_valgrind

extern const char *targeto;
extern const char *targetp;
extern const char *targeti;
extern const char *targetn;
extern const char *targetoffset;
extern int ok;
extern int valgrind;

extern unsigned long long myrandom(void);
extern void forked(void (*)(long long),long long);
extern void *aligned(void *,long long);
extern void *callocplus(long long);
extern void secret(void *,long long);
extern void public(void *,long long);
extern void double_canary(unsigned char *,unsigned char *,unsigned long long);
extern void input_prepare(unsigned char *,unsigned char *,unsigned long long);
extern void output_prepare(unsigned char *,unsigned char *,unsigned long long);
extern void input_compare(const unsigned char *,const unsigned char *,unsigned long long,const char *);
extern void output_compare(const unsigned char *,const unsigned char *,unsigned long long,const char *);
extern void checksum_expected(const char *);
extern void checksum(const unsigned char *,unsigned long long);
extern void checksum_clear(void);
extern void endianness(unsigned char *,unsigned long long,unsigned long long);

#define test_onetimeauth_poly1305 lib1305_test_onetimeauthpoly1305
extern void test_onetimeauth_poly1305(void);
#endif
