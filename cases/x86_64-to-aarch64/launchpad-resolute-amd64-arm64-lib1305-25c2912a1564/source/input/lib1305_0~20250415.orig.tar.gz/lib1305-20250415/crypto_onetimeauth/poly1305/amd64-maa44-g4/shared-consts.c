// linker define mask44
// linker define mask42
// linker define pmask1
// linker define pmask2
// linker define pmask3
// linker define pmask4
// linker define pmask5
// linker define upmask1
// linker define upmask2
// linker define upmask3
// linker define upmask4
// linker define upmask5
// linker define twoexp41
// linker define p0
// linker define p1
// linker define p2

#include "crypto_uint64.h"

const crypto_uint64 CRYPTO_SHARED_NAMESPACE(mask44)   = 0x00000FFFFFFFFFFF;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(mask42)   = 0x000003FFFFFFFFFF;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(pmask1)   = 0x00000FFFFFFFFFFF;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(pmask2)   = 0xFFFFF00000000000;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(pmask3)   = 0x0000000000FFFFFF;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(pmask4)   = 0xFFFFFFFFFF000000;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(pmask5)   = 0x0000000000000003;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(upmask1)  = 0x00000FFFFFFFFFFF;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(upmask2)  = 0x00000000000FFFFF;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(upmask3)  = 0x00000FFFFFF00000;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(upmask4)  = 0x000000FFFFFFFFFF;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(upmask5)  = 0x0000030000000000;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(twoexp41) = 0x0000010000000000;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(p0) = 0xFFFFFFFFFFFFFFFB;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(p1) = 0xFFFFFFFFFFFFFFFF;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(p2) = 0x0000000000000003;
