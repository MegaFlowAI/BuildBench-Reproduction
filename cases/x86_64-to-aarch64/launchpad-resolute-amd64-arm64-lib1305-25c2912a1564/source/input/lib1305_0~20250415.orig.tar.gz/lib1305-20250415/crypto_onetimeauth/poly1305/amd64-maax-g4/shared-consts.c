// linker define mask2
// linker define mask2c
// linker define zero
// linker define p0
// linker define p1
// linker define p2

#include "crypto_uint64.h"

const crypto_uint64 CRYPTO_SHARED_NAMESPACE(mask2) = 0x0000000000000003;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(mask2c) = 0xFFFFFFFFFFFFFFFC;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(zero) = 0x0;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(p0) = 0xFFFFFFFFFFFFFFFB;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(p1) = 0xFFFFFFFFFFFFFFFF;
const crypto_uint64 CRYPTO_SHARED_NAMESPACE(p2) = 0x0000000000000003;
