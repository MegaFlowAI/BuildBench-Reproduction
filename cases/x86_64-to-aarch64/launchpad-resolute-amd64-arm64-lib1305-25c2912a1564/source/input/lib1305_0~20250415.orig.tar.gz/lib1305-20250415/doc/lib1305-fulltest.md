### NAME

lib1305-fulltest - run the full lib1305 test suite

### SYNOPSIS

    lib1305-fulltest

### DESCRIPTION

`lib1305-fulltest`
runs the full suite of tests of
the lib1305 implementation of Poly1305.

The `lib1305-fulltest` output format is subject to change.
A successful test prints a final line saying

    full tests succeeded

and exits 0.
An unsuccessful test exits nonzero without printing that line.

### SEE ALSO

**lib1305-test**(1),
**lib1305**(3)
