The lib1305 implementations of Poly1305
(except for the portable `poly1305/ref` fallback)
are from Kaushik Nath.
The lib1305 infrastructure
is from Daniel J. Bernstein.
Nath's work on this project was
[funded](https://nlnet.nl/project/lib1305/)
through the
[NGI0 Core](https://nlnet.nl/core/) Fund,
a fund established by
[NLnet](https://nlnet.nl)
with financial support from the European Commission's
[Next Generation Internet](https://ngi.eu) program.

Sources of Poly1305 software (this is not a comprehensive list, just
the software that lib1305 is derived from):

   * Sreyosi Bhattacharyya, Kaushik Nath and Palash Sarkar, "Polynomial hashing 
     over prime order fields", Advances in Mathematics of
     Communications 19 (2025), pages 337–378.
     Original release:

     - <https://github.com/kn-cs/polyHash/tree/main/poly1305>

     The assemblies of the various implementations available in the above software are used 
     inside the following lib1305 directories:

     - `crypto_onetimeauth/poly1305/amd64-maax-g1`
     - `crypto_onetimeauth/poly1305/amd64-maax-g4`
     - `crypto_onetimeauth/poly1305/amd64-maax-g8`
     - `crypto_onetimeauth/poly1305/amd64-maax-g16`
     - `crypto_onetimeauth/poly1305/amd64-maax-g32`
     
   * Kaushik Nath, nineteen versions of Poly1305 code new in lib1305 (no
     paper yet) for various platforms.

     - `crypto_onetimeauth/poly1305/amd64-maax-g24`
     - `crypto_onetimeauth/poly1305/amd64-mxaa-g1`     
     - `crypto_onetimeauth/poly1305/amd64-mxaa-g4`
     - `crypto_onetimeauth/poly1305/amd64-mxaa-g8`
     - `crypto_onetimeauth/poly1305/amd64-mxaa-g16`
     - `crypto_onetimeauth/poly1305/amd64-mxaa-g24`     
     - `crypto_onetimeauth/poly1305/amd64-mxaa-g32`     
     - `crypto_onetimeauth/poly1305/amd64-maa64-g1`     
     - `crypto_onetimeauth/poly1305/amd64-maa64-g4`
     - `crypto_onetimeauth/poly1305/amd64-maa64-g8`
     - `crypto_onetimeauth/poly1305/amd64-maa64-g16`
     - `crypto_onetimeauth/poly1305/amd64-maa64-g24`     
     - `crypto_onetimeauth/poly1305/amd64-maa64-g32`     
     - `crypto_onetimeauth/poly1305/amd64-maa44-g1`     
     - `crypto_onetimeauth/poly1305/amd64-maa44-g4`
     - `crypto_onetimeauth/poly1305/amd64-maa44-g8`
     - `crypto_onetimeauth/poly1305/amd64-maa44-g16`
     - `crypto_onetimeauth/poly1305/amd64-maa44-g24`     
     - `crypto_onetimeauth/poly1305/amd64-maa44-g32`
