### NAME

lib1305-test - run some lib1305 correctness tests

### SYNOPSIS

    lib1305-test

### DESCRIPTION

`lib1305-test`
runs some tests of the correctness of
the lib1305 implementation of Poly1305.

The `lib1305-test` output format is subject to change.
As examples of the current format, the lines

    onetimeauth_poly1305 offset 1
    onetimeauth_poly1305 selected implementation amd64-mxaa-g24 compiler clang -Wall -fPIC -fwrapv -Qunused-arguments -O2 -mbmi -mbmi2 -mtune=skylake; Ubuntu clang version 14.0.0-1ubuntu1.1; Target: x86_64-pc-linux-gnu; Thread model: posix; InstalledDir: /usr/bin

mean that `lib1305-test` is testing
the automatically selected `amd64-mxaa-g24` implementation of `poly1305`
with various arrays offset by 1 byte from being aligned,
and a final line saying

    all tests succeeded

means that all tests passed.

### SEE ALSO

**lib1305-fulltest**(1),
**lib1305**(3)
