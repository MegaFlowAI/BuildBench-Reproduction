To download and unpack the latest version of lib1305:

    wget -m https://lib1305.cr.yp.to/lib1305-latest-version.txt
    version=$(cat lib1305.cr.yp.to/lib1305-latest-version.txt)
    wget -m https://lib1305.cr.yp.to/lib1305-$version.tar.gz
    tar -xzf lib1305.cr.yp.to/lib1305-$version.tar.gz
    cd lib1305-$version

Then [install](install.html)
and [test](test.html).

### Archives and changelog (reverse chronological) {#changelog}

[`lib1305-20250415.tar.gz`](lib1305-20250415.tar.gz) [browse](lib1305-20250415.html)

Added tests designed to trigger edge cases in final reduction mod p,
and fixed `maa44` handling of edge cases.
Thanks to Jan Mojzis for the bug report.

Updated to cryptoint 20250414
for portability to armv5.
Thanks to Jan Mojzis for the portability report.

[`lib1305-20250407.tar.gz`](lib1305-20250407.tar.gz) [browse](lib1305-20250407.html)

First release.
