/*
Copyright (C) by Dmitry E. Oboukhov 2006, 2007

  This package is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This package is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this package; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA
*/
#ifndef __UNITS__INFO__H__
#define __UNITS__INFO__H__

#include "unit.h"
/*
  Этот файл сгенерирован при помощи утилиты 'create_units.pl'
  поэтому менять его руками не стоит.
  При генерации данные взяты из файла 'units.conf'
*/

#define UNITS_COUNT   22
#define RAPIDS_COUNT  (19-1)

#define SMALL_CHARGO 0
#define LARGE_CHARGO 1
#define RECYCLER 7

extern unit_info units[22];
extern rapidfire rapids[13][19];

#endif
