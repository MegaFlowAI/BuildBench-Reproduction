/*
Copyright (C) by Dmitry E. Oboukhov 2006, 2007

  This package is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This package is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this package; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA
*/
/* 
  Этот файл сгенерирован при помощи утилиты 'create_units.pl'
  поэтому менять его руками не стоит.
  При генерации данные взяты из файла 'units.conf'

*/
#include "unit.h"

/* Oбщее описание юнитов */
unit_info units[]=
{
  {
    "Small Cargo" /* name */,
    10       /* shield */,
    4000     /* structure */,
    5        /* attack */,
    5000     /* capacity */,
    2000     /* metal */,
    2000     /* crystal */,
    0        /* deut */,
    {
      0      /* ground */,
      0      /* large_chargo */,
      1      /* small_chargo */,
      0      /* recycler */,
    },
    1        /* rapidno */
  },
  {
    "Large Cargo" /* name */,
    25       /* shield */,
    12000    /* structure */,
    5        /* attack */,
    25000    /* capacity */,
    6000     /* metal */,
    6000     /* crystal */,
    0        /* deut */,
    {
      0      /* ground */,
      1      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    2        /* rapidno */
  },
  {
    "Light Fighter" /* name */,
    10       /* shield */,
    4000     /* structure */,
    50       /* attack */,
    50       /* capacity */,
    3000     /* metal */,
    1000     /* crystal */,
    0        /* deut */,
    {
      0      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    3        /* rapidno */
  },
  {
    "Heavy Fighter" /* name */,
    25       /* shield */,
    10000    /* structure */,
    150      /* attack */,
    100      /* capacity */,
    6000     /* metal */,
    4000     /* crystal */,
    0        /* deut */,
    {
      0      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    4        /* rapidno */
  },
  {
    "Cruiser" /* name */,
    50       /* shield */,
    27000    /* structure */,
    400      /* attack */,
    800      /* capacity */,
    20000    /* metal */,
    7000     /* crystal */,
    2000     /* deut */,
    {
      0      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    5        /* rapidno */
  },
  {
    "Battleship" /* name */,
    200      /* shield */,
    60000    /* structure */,
    1000     /* attack */,
    1500     /* capacity */,
    45000    /* metal */,
    15000    /* crystal */,
    0        /* deut */,
    {
      0      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    6        /* rapidno */
  },
  {
    "Colony Ship" /* name */,
    100      /* shield */,
    30000    /* structure */,
    50       /* attack */,
    7500     /* capacity */,
    10000    /* metal */,
    20000    /* crystal */,
    10000    /* deut */,
    {
      0      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    7        /* rapidno */
  },
  {
    "Recycler" /* name */,
    10       /* shield */,
    16000    /* structure */,
    1        /* attack */,
    20000    /* capacity */,
    10000    /* metal */,
    6000     /* crystal */,
    2000     /* deut */,
    {
      0      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      1      /* recycler */,
    },
    8        /* rapidno */
  },
  {
    "Espionage Probe" /* name */,
    0        /* shield */,
    1000     /* structure */,
    0        /* attack */,
    0        /* capacity */,
    0        /* metal */,
    1000     /* crystal */,
    0        /* deut */,
    {
      0      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    0        /* rapidno */
  },
  {
    "Bomber" /* name */,
    500      /* shield */,
    75000    /* structure */,
    1000     /* attack */,
    500      /* capacity */,
    50000    /* metal */,
    25000    /* crystal */,
    15000    /* deut */,
    {
      0      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    9        /* rapidno */
  },
  {
    "Solar Satellite" /* name */,
    1        /* shield */,
    2000     /* structure */,
    1        /* attack */,
    0        /* capacity */,
    0        /* metal */,
    2000     /* crystal */,
    500      /* deut */,
    {
      0      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    0        /* rapidno */
  },
  {
    "Destroyer" /* name */,
    500      /* shield */,
    110000   /* structure */,
    2000     /* attack */,
    2000     /* capacity */,
    60000    /* metal */,
    50000    /* crystal */,
    15000    /* deut */,
    {
      0      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    10       /* rapidno */
  },
  {
    "Deathstar" /* name */,
    50000    /* shield */,
    9000000  /* structure */,
    200000   /* attack */,
    1000000  /* capacity */,
    5000000  /* metal */,
    4000000  /* crystal */,
    1000000  /* deut */,
    {
      0      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    11       /* rapidno */
  },
  {
    "Battlecruiser" /* name */,
    400      /* shield */,
    70000    /* structure */,
    700      /* attack */,
    750      /* capacity */,
    30000    /* metal */,
    40000    /* crystal */,
    15000    /* deut */,
    {
      0      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    12       /* rapidno */
  },
  {
    "Rocket Launcher" /* name */,
    20       /* shield */,
    2000     /* structure */,
    80       /* attack */,
    0        /* capacity */,
    2000     /* metal */,
    0        /* crystal */,
    0        /* deut */,
    {
      1      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    0        /* rapidno */
  },
  {
    "Light Laser" /* name */,
    25       /* shield */,
    2000     /* structure */,
    100      /* attack */,
    0        /* capacity */,
    1500     /* metal */,
    500      /* crystal */,
    0        /* deut */,
    {
      1      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    0        /* rapidno */
  },
  {
    "Heavy Laser" /* name */,
    100      /* shield */,
    8000     /* structure */,
    250      /* attack */,
    0        /* capacity */,
    6000     /* metal */,
    2000     /* crystal */,
    0        /* deut */,
    {
      1      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    0        /* rapidno */
  },
  {
    "Gauss Cannon" /* name */,
    200      /* shield */,
    35000    /* structure */,
    1100     /* attack */,
    0        /* capacity */,
    20000    /* metal */,
    15000    /* crystal */,
    2000     /* deut */,
    {
      1      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    0        /* rapidno */
  },
  {
    "Ion Cannon" /* name */,
    500      /* shield */,
    8000     /* structure */,
    150      /* attack */,
    0        /* capacity */,
    2000     /* metal */,
    6000     /* crystal */,
    0        /* deut */,
    {
      1      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    0        /* rapidno */
  },
  {
    "Plasma Turret" /* name */,
    300      /* shield */,
    100000   /* structure */,
    3000     /* attack */,
    0        /* capacity */,
    50000    /* metal */,
    50000    /* crystal */,
    30000    /* deut */,
    {
      1      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    0        /* rapidno */
  },
  {
    "Small Shield Dome" /* name */,
    2000     /* shield */,
    20000    /* structure */,
    1        /* attack */,
    0        /* capacity */,
    10000    /* metal */,
    10000    /* crystal */,
    0        /* deut */,
    {
      1      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    0        /* rapidno */
  },
  {
    "Large Shield Dome" /* name */,
    10000    /* shield */,
    100000   /* structure */,
    1        /* attack */,
    0        /* capacity */,
    50000    /* metal */,
    50000    /* crystal */,
    0        /* deut */,
    {
      1      /* ground */,
      0      /* large_chargo */,
      0      /* small_chargo */,
      0      /* recycler */,
    },
    0        /* rapidno */
  },
};

/* Скорострелы */
rapidfire rapids[13][19]=
{
  { { 0, 0, 0 }, },

  /* Small Cargo */
  {
    { 10,     5, 0.8 },
    {  8,     5, 0.8 },
  },

  /* Large Cargo */
  {
    { 10,     5, 0.8 },
    {  8,     5, 0.8 },
  },

  /* Light Fighter */
  {
    { 10,     5, 0.8 },
    {  8,     5, 0.8 },
  },

  /* Heavy Fighter */
  {
    { 10,     5, 0.8 },
    {  8,     5, 0.8 },
    {  0,     3, 0.666666666666667 },
  },

  /* Cruiser */
  {
    { 10,     5, 0.8 },
    { 14,    10, 0.9 },
    {  2,     6, 0.833333333333333 },
    {  8,     5, 0.8 },
  },

  /* Battleship */
  {
    { 10,     5, 0.8 },
    {  8,     5, 0.8 },
  },

  /* Colony Ship */
  {
    { 10,     5, 0.8 },
    {  8,     5, 0.8 },
  },

  /* Recycler */
  {
    { 10,     5, 0.8 },
    {  8,     5, 0.8 },
  },

  /* Bomber */
  {
    { 18,    10, 0.9 },
    { 10,     5, 0.8 },
    { 16,    10, 0.9 },
    { 15,    20, 0.95 },
    { 14,    20, 0.95 },
    {  8,     5, 0.8 },
  },

  /* Destroyer */
  {
    { 10,     5, 0.8 },
    { 15,    10, 0.9 },
    {  8,     5, 0.8 },
    { 13,     2, 0.5 },
  },

  /* Deathstar */
  {
    { 17,    50, 0.98 },
    { 14,   200, 0.995 },
    {  6,   250, 0.996 },
    {  8,  1250, 0.9992 },
    { 18,   100, 0.99 },
    {  3,   100, 0.99 },
    {  7,   250, 0.996 },
    {  9,    25, 0.96 },
    { 15,   200, 0.995 },
    { 16,   100, 0.99 },
    {  0,   250, 0.996 },
    { 10,  1250, 0.9992 },
    {  5,    30, 0.966666666666667 },
    {  4,    33, 0.96969696969697 },
    {  1,   250, 0.996 },
    {  2,   200, 0.995 },
    { 11,     5, 0.8 },
    { 13,    15, 0.933333333333333 },
  },

  /* Battlecruiser */
  {
    {  8,     5, 0.8 },
    { 10,     5, 0.8 },
    {  0,     3, 0.666666666666667 },
    {  1,     3, 0.666666666666667 },
    {  3,     4, 0.75 },
    {  4,     4, 0.75 },
    {  5,     7, 0.857142857142857 },
  },
};
