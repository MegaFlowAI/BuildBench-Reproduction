
#libeztrace-memory.so
add_library(eztrace-memory SHARED
  memory.c
)

target_link_libraries(eztrace-memory
  PRIVATE
    dl
    eztrace-core
    eztrace-lib
)

target_compile_options(eztrace-memory
  PRIVATE
    -D_GNU_SOURCE
)

target_include_directories(eztrace-memory
  PRIVATE
  ${CMAKE_SOURCE_DIR}/src/core/include/eztrace-core/
)

install(TARGETS eztrace-memory
  LIBRARY DESTINATION ${CMAKE_INSTALL_LIBDIR}
  RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR}
  INCLUDES DESTINATION ${CMAKE_INSTALL_INCLUDEDIR}
)
