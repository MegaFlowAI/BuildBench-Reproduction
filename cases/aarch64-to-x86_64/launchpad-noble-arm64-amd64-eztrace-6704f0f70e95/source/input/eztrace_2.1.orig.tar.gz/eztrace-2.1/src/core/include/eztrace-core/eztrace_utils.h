#ifndef EZTRACE_UTILS
#define EZTRACE_UTILS

#include <stdio.h>


static void _eztrace_get_current_program_name(char* buffer) {
  char tmp_buffer[1024];
  FILE* f = fopen("/proc/self/cmdline", "r");
  fscanf(f, "%s", tmp_buffer);
  fclose(f);
  sprintf(buffer, "%s", basename(tmp_buffer));
}

#endif	/* EZTRACE_UTILS */
