#ifndef IOTRACER
#define IOTRACER
#error plop
#include "iotracer_to_otf2.h"

void iotracer_start();
void iotracer_stop();

char * get_commande_add();
char * get_commande_remove();

#endif /* IOTRACER */
