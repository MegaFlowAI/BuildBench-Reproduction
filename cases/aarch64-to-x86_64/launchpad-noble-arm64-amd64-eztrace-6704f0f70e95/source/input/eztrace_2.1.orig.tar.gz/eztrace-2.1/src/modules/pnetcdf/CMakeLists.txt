# Compile this module with mpicc
set(CMAKE_C_COMPILER ${MPICC})

add_library(eztrace-pnetcdf SHARED
  pnetcdf.c
)

target_link_libraries(eztrace-pnetcdf
  PRIVATE
    dl
    eztrace-core
    eztrace-lib
    eztrace-instrumentation
    ${pnetcdf_LINK_LIBRARIES}
)


target_include_directories(eztrace-pnetcdf
PUBLIC
  ${pnetcdf_INCLUDE_DIRS}
PRIVATE
  ${CMAKE_SOURCE_DIR}/src/core/include/eztrace-core/
)

#---------------------------------------------

install(TARGETS eztrace-pnetcdf
  LIBRARY DESTINATION ${CMAKE_INSTALL_LIBDIR}
  RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR}
  INCLUDES DESTINATION ${CMAKE_INSTALL_INCLUDEDIR}
)
