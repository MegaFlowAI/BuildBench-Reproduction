add_library(eztrace-pthread SHARED
  pthread.c
)

target_link_libraries(eztrace-pthread
  PRIVATE
    dl
    eztrace-core
    eztrace-lib
    eztrace-instrumentation
)

target_include_directories(eztrace-pthread
  PRIVATE
  ${CMAKE_SOURCE_DIR}/src/core/include/eztrace-core/
)

#---------------------------------------------

install(TARGETS eztrace-pthread
  LIBRARY DESTINATION ${CMAKE_INSTALL_LIBDIR}
  RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR}
  INCLUDES DESTINATION ${CMAKE_INSTALL_INCLUDEDIR}
)
