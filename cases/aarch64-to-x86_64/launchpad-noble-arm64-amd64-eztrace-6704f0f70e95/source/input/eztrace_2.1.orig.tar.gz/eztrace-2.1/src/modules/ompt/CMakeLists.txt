add_library(eztrace-ompt SHARED
  openmp.c
)

target_link_libraries(eztrace-ompt
  PRIVATE
    atomic
    dl
    eztrace-core
    eztrace-lib
    eztrace-instrumentation
    ${OMPT_LIBRARY}
    )

target_include_directories(eztrace-ompt
  PRIVATE
  ${CMAKE_SOURCE_DIR}/src/core/include/eztrace-core/
  ${OMPT_INCLUDE_DIR}
)

target_compile_options(eztrace-ompt
  PUBLIC
  -fopenmp
)

target_link_options(eztrace-ompt
  PUBLIC
  -fopenmp
)

#---------------------------------------------

install(TARGETS eztrace-ompt
  LIBRARY DESTINATION ${CMAKE_INSTALL_LIBDIR}
  RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR}
  INCLUDES DESTINATION ${CMAKE_INSTALL_INCLUDEDIR}
)
