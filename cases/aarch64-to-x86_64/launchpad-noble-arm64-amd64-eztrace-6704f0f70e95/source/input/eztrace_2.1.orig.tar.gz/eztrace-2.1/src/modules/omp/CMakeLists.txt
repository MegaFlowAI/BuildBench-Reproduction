
add_library(eztpomp SHARED
  pomp-lib-dummy/pomp2_fwrapper.c
  pomp-lib-dummy/pomp2_fwrapper_base.c
  pomp-lib-dummy/pomp2_fwrapper_base.h
  pomp-lib-dummy/pomp2_lib.c
  pomp-lib-dummy/pomp2_lib.h
  pomp-lib-dummy/pomp2_region_info.c
  pomp-lib-dummy/pomp2_region_info.h
)

target_include_directories(eztpomp
  PUBLIC
    pomp-lib-dummy
)

target_compile_options(eztpomp
  PRIVATE
    -Wall -Wextra
    -DOPENMP_FOUND
    ${OpenMP_C_FLAGS}
    )

target_link_libraries(eztpomp
  PRIVATE
    eztrace-core
)

target_compile_options(eztpomp
  PRIVATE
    -Wall -Wextra
    -DOPENMP_FOUND
    ${OpenMP_C_FLAGS}
)

#---------------------------------------------

# Create : libeztrace-omp.so

add_library(eztrace-openmp SHARED
  gomp.c
)

target_link_libraries(eztrace-openmp
  PRIVATE
    atomic
    dl
    eztrace-core
    eztrace-instrumentation
    eztrace-lib
    gomp
)

target_compile_options(eztrace-openmp
  PRIVATE
    -Wall -Wextra
    -DOPENMP_FOUND
    ${OpenMP_C_FLAGS}
    -Wno-gnu-zero-variadic-macro-arguments
)


set(EZTRACE_CC_PATH ${CMAKE_CURRENT_BINARY_DIR}/bin/eztrace_cc)
configure_file (eztrace_cc.in ${EZTRACE_CC_PATH} @ONLY)

install(TARGETS eztpomp  eztrace-openmp
  LIBRARY DESTINATION ${CMAKE_INSTALL_LIBDIR})
install(PROGRAMS ${EZTRACE_CC_PATH} DESTINATION ${CMAKE_INSTALL_BINDIR})
