file(GLOB mpi_function_files mpi_funcs/*.c mpi_funcs/*.h)

set(eztrace-mpi_SOURCES
    ${mpi_function_files}
    mpi.c
    mpi_eztrace.h
    )

  # Compile this module with mpicc/mpif90
set(CMAKE_C_COMPILER ${MPICC})
set(CMAKE_Fortran_COMPILER ${MPIF90})

if(CMAKE_Fortran_COMPILER)
  # mpif.h may define a bunch of unused parameter which would generate lots of warnings
  set(eztrace-mpi_SOURCES ${eztrace-mpi_SOURCES}
    mpi3_f.f90  fortran_utils.f90  mpi_f.f90   mpi_fortran.c)
  
  set(CMAKE_Fortran_FLAGS "${CMAKE_Fortran_FLAGS} -Wno-unused-parameter")
endif()


add_library(eztrace-mpi SHARED
  ${eztrace-mpi_SOURCES}
)

target_include_directories(eztrace-mpi
  PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}
    ${CMAKE_SOURCE_DIR}/src/core/include/eztrace-core/
)

target_link_libraries(eztrace-mpi
  PRIVATE
    ${INTERCEPT_LIB}
    eztrace-core
    eztrace-lib
)

target_compile_options(eztrace-mpi
  PRIVATE
    -Wall -Wextra
    -DUSE_MPI3
    -DLD_PRELOAD_NAME=\"${LD_PRELOAD_NAME}\"
    -DMPI_MODULE_NAME=${MPI_MODULE_NAME}
    -Wno-error=incompatible-pointer-types       # TODO
    -Wno-error=pointer-arith                    # TODO
    -Wno-error=int-conversion                   # TODO
  )

set_target_properties(eztrace-mpi
  PROPERTIES
  OUTPUT_NAME eztrace-${MPI_MODULE_NAME}
  )
#----------------------------------------------------

install(TARGETS eztrace-mpi
  LIBRARY DESTINATION ${CMAKE_INSTALL_LIBDIR}
  RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR}
  INCLUDES DESTINATION ${CMAKE_INSTALL_INCLUDEDIR}
)

