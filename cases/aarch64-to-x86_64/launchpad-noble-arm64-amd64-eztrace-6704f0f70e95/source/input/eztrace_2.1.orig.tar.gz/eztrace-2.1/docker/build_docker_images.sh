#!/bin/bash

docker build -f Dockerfile_mpich . -t eztrace/eztrace.mpich:latest
docker build -f Dockerfile_mpich_vite . -t eztrace/eztrace.mpich.vite:latest
docker build -f Dockerfile_openmpi . -t eztrace/eztrace.openmpi:latest
docker build -f Dockerfile_openmpi_vite . -t eztrace/eztrace.openmpi.vite:latest


docker build -f Dockerfile_test_mpich . -t eztrace/eztrace-test:eztrace.mpich
docker build -f Dockerfile_test_openmpi . -t eztrace/eztrace-test:eztrace.openmpi
