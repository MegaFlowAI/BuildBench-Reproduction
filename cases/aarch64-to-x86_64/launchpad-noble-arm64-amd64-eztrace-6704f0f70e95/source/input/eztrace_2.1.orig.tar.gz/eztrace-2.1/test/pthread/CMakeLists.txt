enable_testing()

if (EZTRACE_ENABLE_PTHREAD)

  set(CMAKE_C_FLAGS "-pthread")
  set(LINK_OPTIONS  "-pthread")

  add_executable(dummy_thread dummy_thread.c)
  add_test(build_dummy_thread "${CMAKE_COMMAND}" --build "${CMAKE_BINARY_DIR}" --target dummy_thread)

  add_test (pthread_tests bash "${CMAKE_CURRENT_SOURCE_DIR}/run.sh" DEPENDS build_dummy_thread)
  set(EZTRACE_LIBRARY_PATH "${EZTRACE_LIBRARY_PATH}:${CMAKE_BINARY_DIR}/src/modules/pthread")


  # Get the list of tests, and set environment variables
  get_property(test_list DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR} PROPERTY TESTS)
  set_property(TEST ${test_list}
    PROPERTY ENVIRONMENT
    "EZTRACE_LIBRARY_PATH=${EZTRACE_LIBRARY_PATH}"
    ${TEST_ENVIRONMENT}
  )
endif()
