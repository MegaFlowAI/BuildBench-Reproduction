enable_testing()

if (EZTRACE_ENABLE_OPENMP)

  # openmp tests need to be instrumented with eztrace_cc
  set(CMAKE_C_FLAGS "-fopenmp")
  set(CMAKE_C_COMPILER_LAUNCHER "${CMAKE_BINARY_DIR}/src/modules/omp/bin/eztrace_cc")

  add_executable(openmp_openmp_simple openmp_simple.c)
  add_executable(openmp_test_lock test_lock.c)
  add_executable(openmp_test_nest_lock test_nest_lock.c)
  add_executable(openmp_test_task test_task.c)

  target_link_libraries(openmp_openmp_simple eztpomp)
  target_link_libraries(openmp_test_lock eztpomp)
  target_link_libraries(openmp_test_nest_lock eztpomp)
  target_link_libraries(openmp_test_task eztpomp)

  set_target_properties(openmp_openmp_simple PROPERTIES OUTPUT_NAME "openmp_simple")
  set_target_properties(openmp_test_lock PROPERTIES OUTPUT_NAME "test_lock")
  set_target_properties(openmp_test_nest_lock PROPERTIES OUTPUT_NAME "test_nest_lock")
  set_target_properties(openmp_test_task PROPERTIES OUTPUT_NAME "test_task")

  add_test(build_openmp_simple "${CMAKE_COMMAND}" --build "${CMAKE_BINARY_DIR}" --target openmp_openmp_simple)
  add_test(build_test_lock "${CMAKE_COMMAND}" --build "${CMAKE_BINARY_DIR}" --target openmp_test_lock)
  add_test(build_test_nest_lock "${CMAKE_COMMAND}" --build "${CMAKE_BINARY_DIR}" --target openmp_test_nest_lock)
  add_test(build_test_task "${CMAKE_COMMAND}" --build "${CMAKE_BINARY_DIR}" --target openmp_test_task)

  add_test (openmp_tests bash "${CMAKE_CURRENT_SOURCE_DIR}/run.sh" DEPENDS "openmp_build_openmp_simple;openmp_build_test_lock;openmp_build_test_task")
  set(EZTRACE_LIBRARY_PATH "${EZTRACE_LIBRARY_PATH}:${CMAKE_BINARY_DIR}/src/modules/omp")


  # Get the list of tests, and set environment variables
  get_property(test_list DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR} PROPERTY TESTS)
  set_property(TEST ${test_list}
    PROPERTY ENVIRONMENT
    "EZTRACE_LIBRARY_PATH=${EZTRACE_LIBRARY_PATH}"
    ${TEST_ENVIRONMENT}
  )
endif()
