SVN_REV = "$Rev: 283 $"
LATEST='1.0.1'
REGFI_VERSION = "%s.%s" % (LATEST, SVN_REV.split(' ')[1])
