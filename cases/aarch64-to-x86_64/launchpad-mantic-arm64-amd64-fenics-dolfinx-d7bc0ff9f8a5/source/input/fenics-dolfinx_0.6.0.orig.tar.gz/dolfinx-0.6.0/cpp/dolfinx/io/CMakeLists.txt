set(HEADERS_io
    ${CMAKE_CURRENT_SOURCE_DIR}/dolfin_io.h
    ${CMAKE_CURRENT_SOURCE_DIR}/ADIOS2Writers.h
    ${CMAKE_CURRENT_SOURCE_DIR}/cells.h
    ${CMAKE_CURRENT_SOURCE_DIR}/HDF5Interface.h
    ${CMAKE_CURRENT_SOURCE_DIR}/vtk_utils.h
    ${CMAKE_CURRENT_SOURCE_DIR}/VTKFile.h
    ${CMAKE_CURRENT_SOURCE_DIR}/XDMFFile.h
    ${CMAKE_CURRENT_SOURCE_DIR}/xdmf_function.h
    ${CMAKE_CURRENT_SOURCE_DIR}/xdmf_mesh.h
    ${CMAKE_CURRENT_SOURCE_DIR}/xdmf_meshtags.h
    ${CMAKE_CURRENT_SOURCE_DIR}/xdmf_read.h
    ${CMAKE_CURRENT_SOURCE_DIR}/xdmf_utils.h
    PARENT_SCOPE
)

target_sources(
  dolfinx
  PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/ADIOS2Writers.cpp
          ${CMAKE_CURRENT_SOURCE_DIR}/cells.cpp
          ${CMAKE_CURRENT_SOURCE_DIR}/HDF5Interface.cpp
          ${CMAKE_CURRENT_SOURCE_DIR}/VTKFile.cpp
          ${CMAKE_CURRENT_SOURCE_DIR}/vtk_utils.cpp
          ${CMAKE_CURRENT_SOURCE_DIR}/XDMFFile.cpp
          ${CMAKE_CURRENT_SOURCE_DIR}/xdmf_function.cpp
          ${CMAKE_CURRENT_SOURCE_DIR}/xdmf_mesh.cpp
          ${CMAKE_CURRENT_SOURCE_DIR}/xdmf_utils.cpp
)
