macro(declare_test TESTNAME)
    add_executable(${TESTNAME}
                    ${TESTNAME}.cpp
                    eds-base-test.cpp
                    eds-base-test.h
                    gscopedpointer.h
    )

    if(TEST_XML_OUTPUT)
        set(TEST_ARGS -p -xunitxml -p -o -p test_${testname}.xml)
    else()
        set(TEST_ARGS "")
    endif()

    target_compile_definitions(${TESTNAME} PRIVATE TEST_SUITE)
    target_include_directories(${TESTNAME} PRIVATE
        ${ECAL_INCLUDE_DIRS}
        ${EDATASERVER_INCLUDE_DIRS}
        ${LOMIRI_EDS_INCLUDE_DIRS}
    )

    target_link_libraries(${TESTNAME} PRIVATE
        ${ECAL_LIBRARIES}
        ${EDATASERVER_LIBRARIES}
        ${LOMIRI_EDS_LIBRARIES}
        Qt5::Core
        Qt5::Test
        Qt5::Organizer
        qtorganizer_eds-lib
    )

    add_test(${TESTNAME}
             ${CMAKE_CURRENT_SOURCE_DIR}/run-eds-test.sh ${DBUS_RUNNER} ${CMAKE_CURRENT_BINARY_DIR}/${TESTNAME} ${TESTNAME}
             ${EVOLUTION_CALENDAR_FACTORY} ${EVOLUTION_CALENDAR_SERVICE_NAME}
             ${EVOLUTION_SOURCE_REGISTRY}  ${EVOLUTION_SOURCE_SERVICE_NAME}
             ${GVFSD})
endmacro(declare_test testname)

declare_test(parseecal-test)
declare_test(collections-test)
declare_test(event-test)
declare_test(fetchitem-test)
declare_test(recurrence-test)
declare_test(cancel-operation-test)
declare_test(filter-test)
