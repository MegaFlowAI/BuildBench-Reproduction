set(QORGANIZER_BACKEND qtorganizer_eds)

set(QORGANIZER_BACKEND_SRCS
    qorganizer-eds-fetchrequestdata.cpp
    qorganizer-eds-fetchbyidrequestdata.cpp
    qorganizer-eds-fetchocurrencedata.cpp
    qorganizer-eds-engine.cpp
    qorganizer-eds-enginedata.cpp
    qorganizer-eds-parseeventthread.cpp
    qorganizer-eds-removecollectionrequestdata.cpp
    qorganizer-eds-removerequestdata.cpp
    qorganizer-eds-removebyidrequestdata.cpp
    qorganizer-eds-requestdata.cpp
    qorganizer-eds-savecollectionrequestdata.cpp
    qorganizer-eds-saverequestdata.cpp
    qorganizer-eds-viewwatcher.cpp
    qorganizer-eds-source-registry.cpp
)

set(QORGANIZER_BACKEND_HDRS
    qorganizer-eds-fetchrequestdata.h
    qorganizer-eds-fetchbyidrequestdata.h
    qorganizer-eds-fetchocurrencedata.h
    qorganizer-eds-engine.h
    qorganizer-eds-enginedata.h
    qorganizer-eds-parseeventthread.h
    qorganizer-eds-removecollectionrequestdata.h
    qorganizer-eds-removerequestdata.h
    qorganizer-eds-removebyidrequestdata.h
    qorganizer-eds-requestdata.h
    qorganizer-eds-savecollectionrequestdata.h
    qorganizer-eds-saverequestdata.h
    qorganizer-eds-source-registry.h
    qorganizer-eds-viewwatcher.h
)

add_library(${QORGANIZER_BACKEND}-lib STATIC
    ${QORGANIZER_BACKEND_SRCS}
    ${QORGANIZER_BACKEND_HDRS}
)

target_include_directories(${QORGANIZER_BACKEND}-lib PUBLIC
    $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}>
    ${GLIB_INCLUDE_DIRS}
    ${GIO_INCLUDE_DIRS}
    ${ECAL_INCLUDE_DIRS}
    ${EDATASERVER_INCLUDE_DIRS}
    ${LOMIRI_EDS_INCLUDE_DIRS}
)

target_link_libraries(${QORGANIZER_BACKEND}-lib PUBLIC
    ${GLIB_LIBRARIES}
    ${ECAL_LIBRARIES}
    ${EDATASERVER_LIBRARIES}
    ${LOMIRI_EDS_LIBRARIES}
    Qt5::Core
    Qt5::Organizer
)

add_library(${QORGANIZER_BACKEND} MODULE
    qorganizer-eds-factory.cpp
    qorganizer-eds-factory.h
)

target_include_directories(${QORGANIZER_BACKEND} PRIVATE
    ${GLIB_INCLUDE_DIRS}
    ${GIO_INCLUDE_DIRS}
    ${ECAL_INCLUDE_DIRS}
    ${EDATASERVER_INCLUDE_DIRS}
    ${LOMIRI_EDS_INCLUDE_DIRS}
)

target_link_libraries(${QORGANIZER_BACKEND} PRIVATE
    ${QORGANIZER_BACKEND}-lib
    ${GLIB_LIBRARIES}
    ${ECAL_LIBRARIES}
    ${EDATASERVER_LIBRARIES}
    ${LOMIRI_EDS_LIBRARIES}
    Qt5::Core
    Qt5::Organizer
)

set(QT_INSTALL_PLUGINS "${CMAKE_INSTALL_LIBDIR}/qt5/plugins" CACHE STRING "Qt5 Plugin Directory")

install(TARGETS ${QORGANIZER_BACKEND} LIBRARY DESTINATION ${QT_INSTALL_PLUGINS}/organizer)
