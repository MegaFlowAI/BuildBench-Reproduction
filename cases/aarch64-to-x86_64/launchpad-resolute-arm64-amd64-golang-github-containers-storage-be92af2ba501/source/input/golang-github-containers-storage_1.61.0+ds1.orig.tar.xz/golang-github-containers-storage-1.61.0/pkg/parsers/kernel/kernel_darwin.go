//go:build darwin

// Package kernel provides helper function to get, parse and compare kernel
// versions for different platforms.
package kernel

import (
	"fmt"
	"os/exec"
	"strings"

	"github.com/mattn/go-shellwords"
)

// GetKernelVersion gets the current kernel version.
func GetKernelVersion() (*VersionInfo, error) {
	release, err := getRelease()
	if err != nil {
		return nil, err
	}

	return ParseRelease(release)
}

// getRelease uses `system_profiler SPSoftwareDataType` to get OSX kernel version
func getRelease() (string, error) {
	cmd := exec.Command("system_profiler", "SPSoftwareDataType")
	osName, err := cmd.Output()
	if err != nil {
		return "", err
	}

	var release string
	for line := range strings.SplitSeq(string(osName), "\n") {
		if strings.Contains(line, "Kernel Version") {
			// It has the format like '      Kernel Version: Darwin 14.5.0'
			_, val, ok := strings.Cut(line, ":")
			if !ok {
				return "", fmt.Errorf("kernel version is invalid")
			}

			prettyNames, err := shellwords.Parse(val)
			if err != nil {
				return "", fmt.Errorf("kernel version is invalid: %w", err)
			}

			if len(prettyNames) != 2 {
				return "", fmt.Errorf("kernel version needs to be 'Darwin x.x.x' ")
			}
			release = prettyNames[1]
		}
	}

	return release, nil
}
