Py.initialize ~version:3 ();;
Py.Run.simple_string "print('Hello world!')";;
