.. |igraph| replace:: *igraph*
