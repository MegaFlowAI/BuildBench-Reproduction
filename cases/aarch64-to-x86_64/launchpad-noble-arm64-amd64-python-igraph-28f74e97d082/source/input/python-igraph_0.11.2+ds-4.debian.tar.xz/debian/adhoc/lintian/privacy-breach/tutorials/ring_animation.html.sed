s|href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css|href="/usr/share/fonts-font-awesome/css/font-awesome.min.css"|g
