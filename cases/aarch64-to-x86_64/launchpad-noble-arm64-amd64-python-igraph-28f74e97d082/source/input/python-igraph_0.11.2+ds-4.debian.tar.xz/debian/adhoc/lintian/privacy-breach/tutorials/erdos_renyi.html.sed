s|src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"|src="/usr/share/javascript/mathjax/MathJax.js"|g
