#!/bin/sh -xe

mkdir -p /usr/local/src
cd /usr/local/src

pkg_add wget bison
wget https://www.tcpdump.org/release/libpcap-1.10.5.tar.gz
tar zxf libpcap-1.10.5.tar.gz
cd libpcap-1.10.5
./configure
make
make install
