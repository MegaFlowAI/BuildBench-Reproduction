#!/bin/sh -xe

test -e tc.pcap || ln -s "$srcdir/tc.pcap" tc.pcap

../dnscap -g -ddd -e n -r tc.pcap 2>filters.out
../dnscap -g -ddd -e t -r tc.pcap 2>>filters.out
../dnscap -g -ddd -e nt -r tc.pcap 2>>filters.out
../dnscap -g -ddd -e f -r tc.pcap 2>>filters.out
../dnscap -g -ddd -e y -r tc.pcap 2>>filters.out

../dnscap -g -ddd -e n -r tc.pcap -o use_layers=yes 2>>filters.out
../dnscap -g -ddd -e t -r tc.pcap -o use_layers=yes 2>>filters.out
../dnscap -g -ddd -e nt -r tc.pcap -o use_layers=yes 2>>filters.out
../dnscap -g -ddd -e f -r tc.pcap -o use_layers=yes 2>>filters.out
../dnscap -g -ddd -e y -r tc.pcap -o use_layers=yes 2>>filters.out

grep -v "^dnscap: version " filters.out > filters.out.2

diff filters.out.2 "$srcdir/filters.gold"

