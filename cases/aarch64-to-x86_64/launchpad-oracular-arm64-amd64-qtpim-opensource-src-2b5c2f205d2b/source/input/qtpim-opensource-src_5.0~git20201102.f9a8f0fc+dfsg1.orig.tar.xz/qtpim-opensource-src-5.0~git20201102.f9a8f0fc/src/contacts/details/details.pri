INCLUDEPATH += details \
    ./

PUBLIC_HEADERS += \
    details/qcontactaddress.h \
    details/qcontactanniversary.h \
    details/qcontactavatar.h \
    details/qcontactbirthday.h \
    details/qcontactdetails.h \
    details/qcontactdisplaylabel.h \
    details/qcontactemailaddress.h \
    details/qcontactfamily.h \
    details/qcontactfavorite.h \
    details/qcontactgender.h \
    details/qcontactgeolocation.h \
    details/qcontactglobalpresence.h \
    details/qcontactguid.h \
    details/qcontacthobby.h \
    details/qcontactname.h \
    details/qcontactnickname.h \
    details/qcontactnote.h \
    details/qcontactonlineaccount.h \
    details/qcontactorganization.h \
    details/qcontactphonenumber.h \
    details/qcontactpresence.h \
    details/qcontactringtone.h \
    details/qcontactsynctarget.h \
    details/qcontacttag.h \
    details/qcontacttimestamp.h \
    details/qcontacttype.h \
    details/qcontacturl.h \
    details/qcontactversion.h \
    details/qcontactextendeddetail.h

SOURCES += details/qcontactdetails.cpp
