TEMPLATE = subdirs
SUBDIRS +=
