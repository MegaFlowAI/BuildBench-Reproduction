.. automodule:: cysignals.pysignals
    :members:
