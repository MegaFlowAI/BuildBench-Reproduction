/* This file is part of msolve.
 *
 * msolve is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * msolve is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with msolve.  If not, see <https://www.gnu.org/licenses/>
 *
 * Authors:
 * Jérémy Berthomieu
 * Christian Eder
 * Mohab Safey El Din */

//#include "utils.h"
#include "univmultiply.h"
#include "mpz_upoly_multiply.h"

#define THRESHOLDSHIFT 256 //512

void taylorshift1_naive(mpz_t *, const unsigned long int);

void taylorshift1_dac(mpz_t *, const unsigned long int, mpz_t *, mpz_t **,
                      unsigned long int, const unsigned int);

long USOLVEtaylor_shift_by_1_dac_wsgn_variations(mpz_t *, const unsigned long int,
                                           mpz_t *, mpz_t **, unsigned long int, const unsigned int);

