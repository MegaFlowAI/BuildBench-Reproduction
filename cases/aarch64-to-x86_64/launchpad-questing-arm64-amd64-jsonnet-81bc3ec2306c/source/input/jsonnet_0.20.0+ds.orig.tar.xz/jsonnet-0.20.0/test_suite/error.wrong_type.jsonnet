std.codepoint(42)
