foo(
  bar()
  ,
  baz=qux
)
