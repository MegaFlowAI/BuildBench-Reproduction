true &&
true
