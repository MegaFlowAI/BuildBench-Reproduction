std.parseJson('broken json')
