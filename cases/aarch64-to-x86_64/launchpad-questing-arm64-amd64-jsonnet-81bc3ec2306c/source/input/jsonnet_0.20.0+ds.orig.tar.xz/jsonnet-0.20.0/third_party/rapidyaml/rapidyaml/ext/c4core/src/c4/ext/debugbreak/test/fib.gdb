file fib
run
